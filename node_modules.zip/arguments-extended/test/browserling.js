var it = require("it");

it.reporter("tap");
require("./arguments-extended.test");
it.run();