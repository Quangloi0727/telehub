### 2.0.0

  * Requires Node.js >= 0.10.0
  * Update multiparty to 4.1.2
  * Update on-finished to 2.3.0
  * Update qs to 4.0.0
  * Update type-is to 1.6.4

### 1.2.5

  * Update qs to 2.2.4
  * Update type-is to 1.5.2

### 1.2.4

  * Update qs to 2.2.2

### 1.2.3

  * Update qs to 2.2.1

### 1.2.2

  * Update qs to 2.2.0

### 1.2.1

  * Update multiparty to 3.3.2
  * Update qs to 1.2.0

### 1.2.0

  * Update multiparty to 3.3.1
  * Update qs to 1.1.0

### 1.1.0

 * Update multiparty to 3.3.0
 * Use type-is to check Content-Type

### 1.0.6

 * Fix callback hang in node.js 0.8 on errors

### 1.0.5

 * Update multiparty to 3.2.8

### 1.0.4

 * Fix error causing response to hang
 * Update multiparty to 3.2.6

### 1.0.3

 * Update multiparty to 3.2

### 1.0.2

 * Update multiparty to 3.1

### 1.0.1

 * Update multiparty to 3.0

### 1.0.0

 * revive
