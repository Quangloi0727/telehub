var it = require("it");

it.reporter("tap");

require("./array-extended.test");

it.run();