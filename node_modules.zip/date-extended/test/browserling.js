var it = require("it");

it.reporter("tap");

require("./date-extended.test");

it.run();